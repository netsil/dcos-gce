#ifndef Py_TRACEBACK_H
#define Py_TRACEBACK_H
#ifdef __cplusplus
extern "C" {
#endif

typedef PyObject PyTracebackObject;

#ifdef __cplusplus
}
#endif
#endif /* !Py_TRACEBACK_H */
