#define Py_FileSystemDefaultEncoding   NULL
